//
//  Enums.swift
//  Basic_practice_topic
//
//  Created by OBMac-13 on 09/01/26.
//

import Foundation

class Enums {
    
    enum Directions :String{
        case north = "N"
        case south = "S"
        case east = "E"
        case west = "W"
    }
    
    let moveDirection : Directions = .north
    
    
    enum Student{
        case studentName
        case studentAge
        case studentID
        case studentMarks
    }
}

