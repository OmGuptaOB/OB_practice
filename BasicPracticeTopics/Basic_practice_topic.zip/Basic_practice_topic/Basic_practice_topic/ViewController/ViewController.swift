//
//  ViewController.swift
//  Basic_practice_topic
//
//  Created by OBMac-13 on 07/01/26.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.

        // MARK: - Basic Variables & Constants

        let nameo = "Swift"
        // print(nameo.index(after: nameo.2))

        // Constants
        let accountObj = Constants()
        // accountObj.withdraw(amount: 200)

        var environment = "development"
        let maximumNumberOfLoginAttempts: Int
        // maximumNumberOfLoginAttempts has no value yet.

        if environment == "development" {
            maximumNumberOfLoginAttempts = 100
        } else {
            maximumNumberOfLoginAttempts = 10
        }

        // let maximumNumberOfLoginAttempts : Float = 1.12345612 // 1.12345
        // print(maximumNumberOfLoginAttempts)
        // print(Double(maximumNumberOfLoginAttempts))

        let num: Double = 1.123456001281738
        // print(Float(num))

//        var x = 0.0, y = "hello", z = true

        // y = 34
        // print(x)
        // print(y)
        // print(z)

        var red, green, blue: Double
        red = 1.0
        var a34 = 10
        green = 2.5
        var zvsr = 10 + 2.5
        blue = 3.0

        let unt: UInt8 = 255
        // print(unt)

        // MARK: - Unicode & Identifiers

        let π = 3.14159
        let 你好 = "你好世界"
        let 🐶🐮 = "dogcow"

        let `$` = 12
        let `func` = 10

        let name = "om gupta"
        // name = "om"

        // print("om", "gupta", separator: "&")
        // print("om-", terminator: "")
        // print("gupta")

        // MARK: - Integer Types & Limits

        let a: Int8 = 127
        // let a : Int16 = 12345
        // print(Int8.min)
        // print(Int8.max)
        // print(Int16.min)
        // print(Int16.max)
        // print(Int32.min)
        // print(Int32.max)
        // print(Int64.min)
        // print(Int64.max)

        let value: UInt = 10
        // print(Float(value))

        let decimalInteger = 17
        let binaryInteger = 0b10001
        let binaryInteger2 = 0b11111
        let octalInteger = 0o20
        let hexadecimalInteger = 0x10

        // print(binaryInteger)
        // print(octalInteger)
        // print(hexadecimalInteger)

        // MARK: - Typealias

        typealias i8 = Int8
        var v1: i8 = 10

        let orangesAreOrange = true
        let turnipsAreDelicious = false

        if orangesAreOrange {
            // print("Mmm, tasty turnips!")
        } else {
            // print("Eww, turnips are horrible.")
        }

        // MARK: - Tuples

        let serverResponse = (404, "File Not Found")
        var currentStatus: (Int, String)

        currentStatus.1 = "OK"
        print(currentStatus.1)

        // MARK: - Optionals

        var opt: String?

        let optionOBJ = Optionals()

        let savedName: String? = nil
        let nameToDisplay = savedName ?? "Guest"
        // print(nameToDisplay)

        // MARK: - Arrays

        let objarr = Array()
        // objarr.arraymethods()
        // objarr.arrayof()

        let u = Classes()
        // u.clsArray()

        // MARK: - Tuples (Custom)

        let objtuple = Tuples()
        // objtuple.tupleof()

        // MARK: - Sets

        let setobj = Sets()
        // setobj.setOps()

        // MARK: - Dictionary

        let dictobj = Dictionary()
        // dictobj.dictionaryOps()

        // MARK: - Control Flow

        let flowObj = ControlFlow()
        // flowObj.flowops2()
        // flowObj.accesToLogin(role: "admin")

        // MARK: - Structures & Classes

        var user1 = StructuresClass.User(name: "Shubham")

        let vehicle = Vehicle()
        vehicle.numberOfWheels = 4
        // print("Vehicle: \(vehicle.description)")

        let bike = Bicycle()
        // print(bike.description)

        let hover = hoverboard(color: "red")
        // print(hover.description)

        let namedMeat = Food()
        print(namedMeat.name)

        let recipie = RecipeIngredient(name: "dal bati", quantity: 2)
        print(recipie.country ?? "unknows")

        var breakfastList = [
            ShoppingListItem(),
            ShoppingListItem(name: "Bacon"),
            ShoppingListItem(name: "Eggs", quantity: 6)
        ]

        // MARK: - Failable Initializer Example

        var uer = User(name: "", age: -1)

        // MARK: - Deinitializers

        var dint = Deinitialize.FileLogger(fileName: "Epstine files")
        // print(dint.fileName)
        
        // MARK: - Functions
        var function = Functions()
        
//        print(function.greet("alice", true))
//        if let bound = function.minMax(array: [1,2,3,4,5,6,7,8,9,10,121,2,34,325,4534,635,745,856524,54,4534,5345345,45]){
//            print("max from array \(bound.max) and min from array \(bound.min)")
//        }
        
        Classes.clsarr()
//        function.variadic(nums: 1.2,34.1,5.2,6.2)
        
        
        
        
        func addtoint(_ a : Int,_ b : Int)->Int{
            return a+b
        }
        func multitwoint(_ a : Int,_ b : Int)->Int{
            return a*b
        }

//        var addtwonums  : ( Int, Int) -> Int = addtoint
        var addtwonums = multitwoint
        
        func mathfunc(_ twofunc : (Int,Int) -> Int, _ a : Int, _ b : Int){
            print("value of two nums \(twofunc(a,b))")
        }
//        print(mathfunc(addtwonums, 10, 20))
        
        

        func chooseStepFunction(backward: Bool) -> (Int) -> Int {
            func stepForward(_ input: Int) -> Int {
                return input + 1
            }
            func stepBackward(_ input: Int) -> Int {
                return input - 1
            }
            return backward ? stepBackward : stepForward
        }
        
        var currentValue = 3
        let moveNearerToZero = chooseStepFunction(backward: currentValue > 0)
        
//        print("Counting to zero:")
        // Counting to zero:
        while currentValue != 0 {
//            print("\(currentValue)... ")
            currentValue = moveNearerToZero(currentValue)
        }
//        print("zero!")
        
        

        // MARK: - Methods

        let company = Methods()
        // company.useCompanyCar(car: "BMW")
        // Methods.companyCar(car: "Audi", color: "White")
        // Methods.emp(name: "om", age: 12).person()
        
        var somePoint = Methods.Point(x: 1.0, y: 1.0)
        somePoint.moveBy(x: 2.0, y: 3.0)
//        print("The point is now at (\(somePoint.x), \(somePoint.y))")

        // MARK: - Closures

        let clos = Closure()
        clos.demo()
        // clos.sayHello("om")
        // let output = clos.add(3, 5)
        // print(output)

        // MARK: - Enums

        let enumObj = Enums()
        // print(enumObj.moveDirection)
    }
}
